import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormdilogComponent } from './formdilog/formdilog.component';
import { HttpServiceService } from 'src/app/services/http-service.service';
import { UpdateformComponent } from './updateform/updateform.component';
import { ViewformComponent } from './viewform/viewform.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-party',
  templateUrl: './party.component.html',
  styleUrls: ['./party.component.scss']
})
export class PartyComponent implements OnInit {
  partyData: any;
  srNo: number = 1
  constructor(public dialog: MatDialog, private http: HttpServiceService, private router: Router) { }

  openDialog() {
    this.dialog.open(FormdilogComponent);
  }

  ngOnInit(): void {
    this.http.partyDetail().subscribe(res => {
      console.log(res);
      this.partyData = res.data

    })
  }
  delete(id: string) {
    this.http.deleteParty(id).subscribe(res => {
      console.log(res)
    })
    window.location.reload();

  }
  update(id: string) {
    this.dialog.open(UpdateformComponent);
    this.http.viewParty(id).subscribe(res => {
      this.http.passPartyData(res.data)
    })
  }

  visibility(id: string) {
    this.http.viewParty(id).subscribe(res => {
      console.log(res.data);
      // this.partyData = res.data
      this.http.passPartyData(res.data)
    })

    this.dialog.open(ViewformComponent);
  }
}
