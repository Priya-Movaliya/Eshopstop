import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateorder',
  templateUrl: './updateorder.component.html',
  styleUrls: ['./updateorder.component.scss']
})
export class UpdateorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
