import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from 'src/app/services/http-service.service';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.scss']
})
export class PurchaseComponent implements OnInit {
  buyerPartySKU: any;

  constructor(private http: HttpServiceService) { }

  ngOnInit(): void {
    this.http.orderDetail().subscribe(res => {
      console.log(res.data.buyerSKU);
      this.buyerPartySKU = res.data.partyBuyerSKU;
    })
  }
}
