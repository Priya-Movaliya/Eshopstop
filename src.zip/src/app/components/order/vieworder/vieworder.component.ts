import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from 'src/app/services/http-service.service';

@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  styleUrls: ['./vieworder.component.scss']
})
export class VieworderComponent implements OnInit {
  orderData: any;

  constructor(private http: HttpServiceService) { }

  ngOnInit(): void {
    this.http.view.subscribe(res => {
      this.orderData = res
      
    })
  }

}
