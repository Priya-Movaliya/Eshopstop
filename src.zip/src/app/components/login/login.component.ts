import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { HttpServiceService } from 'src/app/services/http-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  formDetail: FormGroup;
  constructor(private fb: FormBuilder, private router: Router, private http: HttpServiceService) {

    this.formDetail = this.fb.group(
      {
        email: ['', [Validators.required]],
        password: ['', [Validators.required]]
      }
    )
  }

  get email() {
    return this.formDetail.get('email')
  }

  get psw() {
    return this.formDetail.get('password')
  }

  submitLoginData() {
    // console.log(this.formDetail.value)
    this.http.login(this.formDetail.value).subscribe(res => {
      console.log('Data added successfully!')
      console.log(res);
      localStorage.setItem("secret_token", res.data.token)
      this.router.navigate(['/admin']);
    }, (err) => {
      console.log(err);
    })

  }

  ngOnInit(): void {
  }

}
