import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from 'src/app/services/http-service.service';

@Component({
  selector: 'app-viewcourier',
  templateUrl: './viewcourier.component.html',
  styleUrls: ['./viewcourier.component.scss']
})
export class ViewcourierComponent implements OnInit {
  courierData: any;

  constructor(private http: HttpServiceService) { }

  ngOnInit(): void {
    this.http.view.subscribe(res => {
      this.courierData = res
      
    })
  }
}
