import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ProductformComponent } from './productform/productform.component';
import { HttpServiceService } from 'src/app/services/http-service.service';
import { ViewProductComponent } from './view-product/view-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  partyData: any;
  srNo: number = 1
  constructor(public dialog: MatDialog, private http: HttpServiceService) { }

  openDialog() {
    this.dialog.open(ProductformComponent);
  }

  ngOnInit(): void {
    this.http.productDetail().subscribe(res => {
      this.partyData = res.data
      console.log(res);

    })
  }
  delete(id: string) {
    this.http.deleteProduct(id).subscribe(res => {
      console.log(res)
    })
    window.location.reload();

  }
  update(id: string) {
    this.dialog.open(UpdateProductComponent);
    this.http.viewProduct(id).subscribe(res => {
      this.http.passProductData(res.data)
    })
  }

  visibility(id: string) {
    this.http.viewProduct(id).subscribe(res => {
      console.log(res.data);
      this.http.passProductData(res.data)
    })
    this.dialog.open(ViewProductComponent)
   
  }

}
