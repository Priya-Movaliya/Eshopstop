import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from 'src/app/services/http-service.service';


@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.scss']
})
export class ViewProductComponent implements OnInit {

  productData: any;
  constructor(private http: HttpServiceService) { }


  ngOnInit(): void {
    this.http.view.subscribe(res => {
      this.productData = res
    })
  }

}
