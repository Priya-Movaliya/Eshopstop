import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpServiceService } from 'src/app/services/http-service.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {
  formDetail: FormGroup;
  checkFocus: boolean = false
  emailPattern: string = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$'

  pswPattern: string = '^[a-zA-Z0-9]{8,15}$'

  constructor(private fb: FormBuilder, private router: Router, private http: HttpServiceService) {

    this.formDetail = this.fb.group(
      {
        firstName: ['', [Validators.required]],
        lastName: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
        password: ['', [Validators.required, Validators.pattern(this.pswPattern)]],
        // confirmPassword: ['', Validators.required],
      },
      // { validators: this.passwordVerification('password', 'confirmPassword') }
    )
  }
  formValidation(data: string) {
    return this.formDetail.get(data)
  }

  focus() {
    this.checkFocus = true;
  }
  submitSignUpData() {
    // console.log(this.formDetail.value)
    this.router.navigate(['/login']);

    this.http.registration(this.formDetail.value).subscribe(() => {
      console.log('Data added successfully!')

    }, (err) => {
      console.log(err);
    })


  }

  ngOnInit(): void {

  }

  // passwordVerification(controlPassword: string, controlConfirmPassword: string) {
  //   return (formGroup: FormGroup) => {
  //     const password = formGroup.controls[controlPassword];
  //     const confirmPassword = formGroup.controls[controlConfirmPassword];

  //     if (password.value !== confirmPassword.value) {
  //       confirmPassword.setErrors({ passwordVerification: true });
  //     }
  //   }
  // }

}
