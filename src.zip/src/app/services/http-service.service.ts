import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { catchError, Observable, Subject } from 'rxjs';
import { registrationModel, loginModel } from './interface';

@Injectable({
  providedIn: 'root'
})
export class HttpServiceService {

  API_URL: string = 'http://192.168.0.59:5000';

  private viewData = new Subject<any>();
  public view = this.viewData.asObservable();

  constructor(private http: HttpClient) { }

  registration(data: registrationModel): Observable<any> {

    return this.http.post(`${this.API_URL}/auth/signup`, data)

  }
  login(data: loginModel): Observable<any> {

    return this.http.post(`${this.API_URL}/auth/login`, data)

  }
  getState(): Observable<any> {

    return this.http.get(`${this.API_URL}/location/getState`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  getCity(stateId: string): Observable<any> {

    return this.http.get(`${this.API_URL}/location/getStateCities/${stateId}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  party(data: object): Observable<any> {

    return this.http.post(`${this.API_URL}/vendor`, data, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  partyDetail(): Observable<any> {

    return this.http.get(`${this.API_URL}/vendor`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  deleteParty(id: string): Observable<any> {
    return this.http.delete(`${this.API_URL}/vendor/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }

  updateParty(id: string, data: any): Observable<any> {

    console.log("======token======", typeof localStorage.getItem('secret_token'));

    return this.http.put(`${this.API_URL}/vendor/${id}`, data, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  viewParty(id: string): Observable<any> {
    return this.http.get(`${this.API_URL}/vendor/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  passPartyData(data: any) {
    this.viewData.next(data);
    console.log(data._id);

  }
  product(data: object): Observable<any> {
    return this.http.post(`${this.API_URL}/product`, data, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  productDetail(): Observable<any> {

    return this.http.get(`${this.API_URL}/product`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }
  updateProduct(id: string, data: any) {


    return this.http.put(`${this.API_URL}/product/${id}`, data, {

      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  deleteProduct(id: string) {
    return this.http.delete(`${this.API_URL}/product/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }

  viewProduct(id: string): Observable<any> {
    console.log("hello");

    return this.http.get(`${this.API_URL}/product/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  passProductData(data: any) {
    this.viewData.next(data);
    console.log(data._id);

  }

  category(): Observable<any> {

    return this.http.get(`${this.API_URL}/category`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }
  order(data: object): Observable<any> {

    return this.http.post(`${this.API_URL}/order`, data, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  orderDetail(): Observable<any> {

    return this.http.get(`${this.API_URL}/order`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  deleteOrder(id: string): Observable<any> {
    return this.http.delete(`${this.API_URL}/order/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }

  updateOrder(id: string): Observable<any> {
    return this.http.put(`${this.API_URL}/order/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  viewOrder(id: string): Observable<any> {
    return this.http.get(`${this.API_URL}/order/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  passOrderData(data: any) {
    this.viewData.next(data);
    console.log(data._id);

  }

  courier(data: object): Observable<any> {

    return this.http.post(`${this.API_URL}/courier`, data, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  courierDetail(): Observable<any> {

    return this.http.get(`${this.API_URL}/courier`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    });
  }

  deleteCourier(id: string): Observable<any> {
    return this.http.delete(`${this.API_URL}/courier/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }

  updateCourier(id: string, data: any): Observable<any> {
    return this.http.put(`${this.API_URL}/courier/${id}`, data, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  viewCourier(id: string): Observable<any> {
    return this.http.get(`${this.API_URL}/courier/${id}`, {
      headers: new HttpHeaders({
        'Authorization': `${localStorage.getItem('secret_token')}`
      })
    })
  }
  passCourierData(data: any) {
    this.viewData.next(data);
    console.log(data._id);

  }

}







