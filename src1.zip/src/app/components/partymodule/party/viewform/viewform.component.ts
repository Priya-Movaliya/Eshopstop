import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from 'src/app/services/http-service.service';
import { PartyServiceService } from 'src/app/services/party-service.service';

@Component({
  selector: 'app-viewform',
  templateUrl: './viewform.component.html',
  styleUrls: ['./viewform.component.scss']
})
export class ViewformComponent implements OnInit {
  partyData: any;
  constructor(private partyService: PartyServiceService) { }

  ngOnInit(): void {
  
    this.partyService.view.subscribe(res => {
      this.partyData = res

    })

  }

}


