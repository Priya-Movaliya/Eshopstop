import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PurchaseComponent } from './purchase/purchase.component';
import { SellComponent } from './sell/sell.component';
import { HttpServiceService } from 'src/app/services/http-service.service';
import { UpdateorderComponent } from './updateorder/updateorder.component';
import { VieworderComponent } from './vieworder/vieworder.component';
import { OrderServiceService } from 'src/app/services/order-service.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {
  typeValue: string = "seller"
  partyData: any;

  constructor(public dialog: MatDialog, private http: HttpServiceService, private orderService: OrderServiceService) { }

  openPurchaseDialog() {
    this.dialog.open(PurchaseComponent);
  }
  openSellDialog() {
    this.dialog.open(SellComponent);
  }

  ngOnInit(): void {
    this.orderService.orderDetail().subscribe(res => {
      console.log(res);
      this.partyData = res.data.order
    })
  }

  delete(id: string) {
    this.orderService.deleteOrder(id).subscribe(res => {
      console.log(res)
    })
    window.location.reload();

  }
  update(id: string) {
    this.dialog.open(UpdateorderComponent);
    this.orderService.viewOrder(id).subscribe(res => {
      this.orderService.passOrderData(res.data)
    })
  }

  visibility(id: string) {
    this.orderService.viewOrder(id).subscribe(res => {
      console.log(res.data);
      // this.partyData = res.data
      this.orderService.passOrderData(res.data)
    })

    this.dialog.open(VieworderComponent);
  }

}
