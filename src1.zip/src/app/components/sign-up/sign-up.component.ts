import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpServiceService } from 'src/app/services/http-service.service';
import { RegistrationServiceService } from 'src/app/services/registration-service.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {
  formDetail: FormGroup;
  checkFocus: boolean = false

  constructor(private fb: FormBuilder, private router: Router, private registrationService: RegistrationServiceService) {

    this.formDetail = this.fb.group(
      {
        firstName: ['', [Validators.required]],
        lastName: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@gmail\.+[a-z]{2,4}$")]],
        password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,30}')]],
        // confirmPassword: ['', Validators.required],
      },
      // { validators: this.passwordVerification('password', 'confirmPassword') }
    )
  }
  formValidation(data: string) {
    return this.formDetail.get(data)
  }

  focus() {
    this.checkFocus = true;
  }
  submitSignUpData() {
    // console.log(this.formDetail.value)
    this.router.navigate(['/login']);

    this.registrationService.registration(this.formDetail.value).subscribe(() => {
      console.log('Data added successfully!')

    }, (err: any) => {
      console.log(err);
    })


  }

  ngOnInit(): void {

  }

  // passwordVerification(controlPassword: string, controlConfirmPassword: string) {
  //   return (formGroup: FormGroup) => {
  //     const password = formGroup.controls[controlPassword];
  //     const confirmPassword = formGroup.controls[controlConfirmPassword];

  //     if (password.value !== confirmPassword.value) {
  //       confirmPassword.setErrors({ passwordVerification: true });
  //     }
  //   }
  // }

}
